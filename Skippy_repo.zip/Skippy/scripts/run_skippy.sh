#!/usr/bin/env bash
set -euo pipefail
python -m skippy --config config/default.toml
